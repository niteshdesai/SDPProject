abstract class ExceptionHandler {
    protected ExceptionHandler nextHandler;
    
    public void setNextHandler(ExceptionHandler nextHandler) {
        this.nextHandler = nextHandler;
    }
    
    public abstract void handleException(Exception exception);
}