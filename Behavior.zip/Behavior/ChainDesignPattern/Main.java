public class Main {
    public static void main(String[] args) {
     
        ExceptionHandler dbHandler = new DatabaseExceptionHandler();
        ExceptionHandler networkHandler = new NetworkExceptionHandler();
        ExceptionHandler validationHandler = new ValidationExceptionHandler();
        ExceptionHandler defaultHandler = new DefaultExceptionHandler();
        
   
        dbHandler.setNextHandler(networkHandler);
        networkHandler.setNextHandler(validationHandler);
        validationHandler.setNextHandler(defaultHandler);

        Exception[] exceptions = {
            new DatabaseException("Connection timeout"),
            new NetworkException("Server unreachable"),
            new ValidationException("Invalid user input"),
            new ArithmeticException("Division by zero")  
        };
        
        
        for (Exception ex : exceptions) {
            System.out.println("\nProcessing exception: " + ex.getClass().getSimpleName());
            dbHandler.handleException(ex);
        }
    }
}