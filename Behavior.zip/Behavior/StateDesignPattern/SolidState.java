class SolidState implements WaterState {
    @Override
    public void applyHeat(Water water) {
        System.out.println("Ice is melting to Liquid...");
        water.setState(new LiquidState());
    }
    
    @Override
    public void applyCold(Water water) {
        System.out.println("Ice remains solid - already frozen!");
    }
}