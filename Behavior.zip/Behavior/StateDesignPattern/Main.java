public class Main {
    public static void main(String[] args) {
        Water water = new Water();
        
        // Starting as liquid
        System.out.println("Starting with liquid water:");
        water.heat(); 
        water.heat();  
        water.cold(); 
        water.cold(); 
        water.cold(); 
        water.heat();  
    }
}