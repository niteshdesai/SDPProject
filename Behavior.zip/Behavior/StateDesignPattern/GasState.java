class GasState implements WaterState {
    @Override
    public void applyHeat(Water water) {
        System.out.println("Gas remains gas - already evaporated!");
    }
    
    @Override
    public void applyCold(Water water) {
        System.out.println("Gas is condensing to Liquid...");
        water.setState(new LiquidState());
    }
}