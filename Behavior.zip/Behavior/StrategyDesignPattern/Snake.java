public interface Snake {
    void display();
    void performBite();
    void setBiteBehavior(BiteBehavior biteBehavior); 
}